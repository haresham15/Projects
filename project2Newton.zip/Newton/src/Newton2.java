import components.simplereader.SimpleReader;
import components.simplereader.SimpleReader1L;
import components.simplewriter.SimpleWriter;
import components.simplewriter.SimpleWriter1L;

/**
 * Put a short phrase describing the program here.
 *
 * @author Put your name here
 *
 */
public final class Newton2 {

    /**
     * No argument constructor--private to prevent instantiation.
     */
    private Newton2() {
    }

    /**
     * Computes estimate of square root of x to within relative error 0.01%.
     *
     * @param x
     *            positive number to compute square root of
     * @return estimate of square root
     */

    private static double newtonProcess(double x) {
        double epsilon = 0.0001;
        double r = x;

        if (r == 0) {
            return 0;
        }

        while (Math.abs(r * r - x) / x >= epsilon * epsilon) {
            r = (r + x / r) / 2.0;
        }
        return r;
    }

    public static void main(String[] args) {
        SimpleReader in = new SimpleReader1L();
        SimpleWriter out = new SimpleWriter1L();
        /*
         * Put your main program code here; it may call myMethod as shown
         */
        out.println("Would you like to calculate a square root (enter y or n)? ");
        String programRun = in.nextLine();

        if (programRun.equals("y")) {
            out.println(
                    "What would you like to calculate the square root of (enter a positive double)? ");
            double numInput = in.nextDouble();

            /*
             * Newton 2.0
             */
            if (numInput == 0) {
                double ans = newtonProcess(numInput);
                out.println("The approximated square root is " + ans);
            } else {
                double ans = newtonProcess(numInput);
                out.println("The approximated square root is " + ans);
            }
        } else {
            out.println("Program Terminated");
        }
        /*
         * Close input and output streams
         */
        in.close();
        out.close();
    }

}
