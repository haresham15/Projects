import components.naturalnumber.NaturalNumber;
import components.naturalnumber.NaturalNumber2;
import components.simplereader.SimpleReader;
import components.simplereader.SimpleReader1L;
import components.simplewriter.SimpleWriter;
import components.simplewriter.SimpleWriter1L;
import components.utilities.Reporter;
import components.xmltree.XMLTree;
import components.xmltree.XMLTree1;

/**
 * Program to evaluate XMLTree expressions of {@code int}.
 *
 * @author Haresh Murugesan
 *
 */
public final class XMLTreeNNExpressionEvaluatorNN {
    /**
     * Private constructor so this utility class cannot be instantiated.
     */
    private XMLTreeNNExpressionEvaluatorNN() {
    }

    /**
     * Evaluate the given expression.
     *
     * @param exp
     *            the {@code XMLTree} representing the expression
     * @return the value of the expression
     * @requires <pre>
     * [exp is a subtree of a well-formed XML arithmetic expression]  and
     *  [the label of the root of exp is not "expression"]
     * </pre>
     * @ensures evaluate = [the value of the expression]
     */
    private static NaturalNumber evaluate(XMLTree exp) {
        assert exp != null : "Violation of: exp is not null";

        NaturalNumber number1, number2;
        NaturalNumber solution = new NaturalNumber2();
        //errors to print when dividing by zero and going to negatives
        String errorSubtract = "There is an error due to going to the negatives";
        String errorDivide = "dividing by 0 causes an error";

        //one num
        if (!exp.child(0).hasAttribute("value")) {
            number1 = evaluate(exp.child(0));
        } else {
            number1 = new NaturalNumber2(
                    Integer.parseInt(exp.child(0).attributeValue("value")));
        }
        //second num
        if (!exp.child(1).hasAttribute("value")) {
            number2 = evaluate(exp.child(0));
        } else {
            number2 = new NaturalNumber2(
                    Integer.parseInt(exp.child(1).attributeValue("value")));
        }

        //operator searching
        String operation = exp.label();
        if (operation.equals("plus")) {
            number1.add(number2);
        } else if (operation.equals("minus")) {
            if (number2.compareTo(number1) > 0) {
                Reporter.fatalErrorToConsole(errorSubtract);
            } else {
                number1.subtract(number2);
            }
        } else if (operation.equals("times")) {
            number2.multiply(number1);
        }
        //similar to the minus to make sure to return the error message in the minus calculator
        else if (operation.equals("divde")) {
            if (number2.isZero()) {
                Reporter.fatalErrorToConsole(errorDivide);
            } else {
                number1.divide(number2);
            }
        }
        solution.copyFrom(number1);
        return solution;
    }

    /**
     * Main method.
     *
     * @param args
     *            the command line arguments
     */
    public static void main(String[] args) {
        SimpleReader in = new SimpleReader1L();
        SimpleWriter out = new SimpleWriter1L();

        out.print("Enter the name of an expression XML file: ");
        String file = in.nextLine();
        while (!file.equals("")) {
            XMLTree exp = new XMLTree1(file);
            out.println(evaluate(exp.child(0)));
            out.print("Enter the name of an expression XML file: ");
            file = in.nextLine();
        }

        in.close();
        out.close();
    }

}
