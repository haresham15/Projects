import components.map.Map;
import components.map.Map1L;
import components.queue.Queue;
import components.queue.Queue1L;
import components.simplereader.SimpleReader;
import components.simplereader.SimpleReader1L;
import components.simplewriter.SimpleWriter;
import components.simplewriter.SimpleWriter1L;

/**
 * Put a short phrase describing the program here.
 *
 * @author Haresh Murugesan
 *
 */
public final class GlossaryProject {
    /**
     * No argument constructor--private to prevent instantiation.
     */
    private GlossaryProject() {
    }

    /**
     * Main method.
     *
     * @param args
     *            the command line arguments
     */
    public static void readGlossaryData(SimpleReader input,
            Map<String, String> wordDefMap, Queue<String> termQueue) {
        String term = "";
        StringBuilder def = new StringBuilder();

        //extracting the glossary data
        while (!input.atEOS()) {
            String line = input.nextLine();
            if (line.isBlank()) {
                if (def.length() > 0 && !term.isEmpty()) {
                    wordDefMap.add(term, def.toString());
                    termQueue.enqueue(term);
                    term = "";
                    def.setLength(0);
                }
            } else if (term.isEmpty()) {
                term = line;
            } else {
                def.append(line).append("");
            }
        }
        if (!term.isEmpty() && def.length() > 0) {
            wordDefMap.add(term, def.toString());
            termQueue.enqueue(term);
        }
        //returning all the glossary data
    }

    public static void index(SimpleWriter out, Queue<String> termQueue) {
        out.println("<html>");
        out.println("<head><title>Glossary</title></head>");
        out.println("<body>");

        for (String term : termQueue) {
            out.println("<li> <a href =\"" + term + ".html\">" + term + "</a></li>");
        }
        out.println("</ul>");
        out.println("</body>");
        out.println("</html>");
    }

    public static void pages(String term, Map<String, String> wordDefMap,
            Queue<String> termQueue, String folder) {

        SimpleWriter file = new SimpleWriter1L(folder + term + ".html");
        file.println("<html>");
        file.println("<head><title>" + term + "</title></head>");
        file.println("<body>");
        file.println("<h2><b><i><font color='red'>" + term + "</font></i></b></h2>");
        //using the value of the map to find the map definition for that term
        String def = wordDefMap.value(term);
        for (String otherTerm : termQueue) {
            def = def.replaceAll("\\b" + otherTerm + "\\b",
                    "<a href=\"" + otherTerm + ".html\">" + otherTerm + "</a>");
        }
        file.println("<p>" + def + "</p>");
        file.println("<hr>");
        file.println("<p><a href=\"index.html\">back to index </a></p>");
        file.println("</body>");
        file.println("</html>");

        file.close();
    }

    public static void alphabetical(Queue<String> termQueue) {
        Queue<String> sorted = new Queue1L<>();
        while (termQueue.length() > 0) {
            String term = termQueue.dequeue();
            boolean checker = false;
            for (int i = 0; i < sorted.length(); i++) {
                String current = sorted.dequeue();
                if (!checker && term.compareTo(current) < 0) {
                    sorted.enqueue(term);
                    checker = true;
                }
                sorted.enqueue(current);
            }
            if (!checker) {
                sorted.enqueue(term);
            }
        }
        while (sorted.length() > 0) {
            termQueue.enqueue(sorted.dequeue());
        }
    }

    public static void main(String[] args) {
        SimpleReader in = new SimpleReader1L();
        SimpleWriter out = new SimpleWriter1L();

        out.println("enter the input name of the file: ");
        String inputFileName = in.nextLine();
        //put it into the fileReader
        SimpleReader fileReader = new SimpleReader1L(inputFileName);

        out.println("enter the output folder");
        String output = in.nextLine();
        if (!output.endsWith("/")) {
            output += "/";
        }

        //creating the maps of strings and definitions for their terms
        Map<String, String> wordDefMap = new Map1L<>();
        Queue<String> termQueue = new Queue1L<>();

        readGlossaryData(fileReader, wordDefMap, termQueue);
        alphabetical(termQueue);

        SimpleWriter indexWriter = new SimpleWriter1L(output + "index.html");
        index(indexWriter, termQueue);

        //to generate the pages, you need to have a loop to generate a seperate page for each of the different terms and definitions
        String checkers = "";
        for (String term : termQueue) {
            pages(term, wordDefMap, termQueue, output);
        }

        out.println("program done, can i please have an A!");
        in.close();
        out.close();
    }

}
