import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.io.File;
import java.io.IOException;

//bring all the imports in

import org.junit.Test;

import components.map.Map;
import components.map.Map1L;
import components.queue.Queue;
import components.queue.Queue1L;
import components.simplereader.SimpleReader1L;
import components.simplewriter.SimpleWriter;
import components.simplewriter.SimpleWriter1L;

public class ExtraCreditJUnit {

    @Test
    public void test() {
        fail("Not yet implemented");
    }

    private static final String INPUT_FILE = "testInput.txt";
    private static final String OUTPUT_FOLDER = "testOutput/";

    public void testAlphabetical() {
        Queue<String> termQueue = new Queue1L<>();
        termQueue.enqueue("Banana");
        termQueue.enqueue("Apple");
        termQueue.enqueue("Cherry");
        GlossaryProject.alphabetical(termQueue);
        // Check that the terms are sorted
        assertEquals("Apple", termQueue.dequeue());
        assertEquals("Banana", termQueue.dequeue());
        assertEquals("Cherry", termQueue.dequeue());
    }

    public void testIndex() throws IOException {
        Queue<String> termQueue = new Queue1L<>();
        termQueue.enqueue("Term1");
        termQueue.enqueue("Term2");

        try (SimpleWriter out = new SimpleWriter1L(OUTPUT_FOLDER + "index.html")) {
            GlossaryProject.index(out, termQueue);
        }

        // Verify that the index.html file was created
        File indexFile = new File(OUTPUT_FOLDER + "index.html");
        assertTrue(indexFile.exists());
    }

    public void testPages() throws IOException {
        Map<String, String> wordDefMap = new Map1L<>();
        wordDefMap.add("Term1", "Definition of Term1");
        wordDefMap.add("Term2", "Definition of Term2 with Term1 mentioned.");
        Queue<String> termQueue = new Queue1L<>();
        termQueue.enqueue("Term1");
        termQueue.enqueue("Term2");

        GlossaryProject.pages("Term2", wordDefMap, termQueue, OUTPUT_FOLDER);

        File termFile = new File(OUTPUT_FOLDER + "Term2.html");
        assertTrue(termFile.exists());

        //like basically tests to see the correct terms get output dealing with the output folder and what it has.
    }

    public void testReadGlossaryData() {
        Map<String, String> wordDefMap = new Map1L<>();
        Queue<String> termQueue = new Queue1L<>();

        try (SimpleReader1L input = new SimpleReader1L(INPUT_FILE)) {
            GlossaryProject.readGlossaryData(input, wordDefMap, termQueue);
        }
        assertTrue(wordDefMap.hasKey("Term1"));
        assertTrue(wordDefMap.hasKey("Term2"));
        assertEquals("Definition of Term1", wordDefMap.value("Term1"));
        assertEquals("Definition of Term2 with Term1 mentioned.",
                wordDefMap.value("Term2"));
        assertEquals(2, termQueue.length());
        assertEquals("Term1", termQueue.dequeue());
        assertEquals("Term2", termQueue.dequeue());
    }

}
